from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('registration/', views.registration,name='registration'),
    path('otp_verify/',views.otp_verify, name = 'otp_verify'),
    path('citizen_login/',views.citizen_login,name='citizen_login'),
    path('citizen_logout/',views.citizen_logout,name='citizen_logout'),
    path('citizen_profile/',views.citizen_profile, name='citizen_profile'),

    path('file_fir/',views.file_fir,name='file_fir'),
    path('file_complain/',views.file_complain,name='file_complain'),
    path('police_station/',views.police_station,name='police_station'),
    path('search_police_station/',views.search_police_station, name = 'search_police_station'),
    path('feedback/',views.feedback,name = 'feedback'),
    path('Upload_photos_videos/',views.photos_videos,name = 'Upload_photos_videos'),

    path("inspector/",views.inspector,name="inspector"),
    path("inspector_index/",views.inspector_index,name = "inspector_index")
]