from django import forms
from myapp import models

class UserModelForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    Confirm_password = forms.CharField(widget=forms.PasswordInput)
    class Meta():
        model = models.User
        fields = ( 'username','first_name', 'last_name', 'email', 'password',)

    def clean(self):
        cleaned_data = super(UserModelForm, self).clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("Confirm_password")

        if password != confirm_password:
            raise forms.ValidationError(
                "password and confirm_password does not match"
            )

class CitizenprofileModelForm(forms.ModelForm):
    class Meta():
        model = models.Citizenprofile
        fields = ('profile_pic','mobile_no','phone_no','dob','gender','address','City','state','pincode')


class FirModelForm(forms.ModelForm):
    class Meta():
        model = models.Fir
        widgets = {
            'incident_place': forms.Textarea(attrs={'rows':4, 'cols':40}),
            'Crime_Description': forms.Textarea(attrs={'rows':10, 'cols':40}),
            'Fir_againts': forms.Textarea(attrs={'rows':5, 'cols':40}),
        }
        fields = ('incident_place','Date_and_Time','Crime_Description','Fir_againts','proof')

class ComplainModelForm(forms.ModelForm):
    class Meta():
        model = models.Complain
        widgets = {
            'incident_place': forms.Textarea(attrs={'rows':4, 'cols':40}),
            'Crime_Description': forms.Textarea(attrs={'rows':10, 'cols':40}),
            'complain_againts': forms.Textarea(attrs={'rows':5, 'cols':40}),
        }
        fields = ('incident_place','Date_and_Time','Crime_Description','complain_againts','proof')

class Police_StationModelForm(forms.ModelForm):
    class Meta():
        model = models.Police_Station
        widgets = {
            'address': forms.Textarea(attrs={'rows':4, 'cols':40})
        }
        fields = '__all__'
        
class FeedbackModelForm(forms.ModelForm):
    class Meta():
        model = models.Feedback
        fields = ('Feedback',)

class Photos_VideosModelForm(forms.ModelForm):
    class Meta():
        model = models.Photos_Videos
        fields = ('Description','Photo','Video')