from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

# Create your models here.
class  Citizenprofile(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    profile_pic = models.ImageField(upload_to='profile_pic')
    GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),
    )
    mobile_no = models.IntegerField()
    phone_no = models.IntegerField()
    dob = models.DateField()
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    address = models.TextField()
    City = models.CharField(max_length=20)
    state = models.CharField(max_length=20)
    pincode = models.IntegerField()

    def __str__(self):
        return self.user.username

class Fir(models.Model):
    Satus_choices = (
        ('Activate','Activate'),
        ('Inprocess', 'Inprocess'),
        ('Closed','Closed')
    )
    username = models.ForeignKey(User, on_delete=models.CASCADE)
    incident_place = models.TextField()
    Date_and_Time = models.DateTimeField()
    Crime_Description = models.TextField()
    Fir_againts = models.TextField()
    proof = models.FileField(upload_to='proof', null=True)
    status = models.CharField(max_length=20, choices=Satus_choices)
    Reason = models.CharField(max_length=256)
    FIR_Date_and_Time = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.username.username

class Complain(models.Model):
    Satus_choices = (
        ('Activate','Activate'),
        ('Inprocess', 'Inprocess'),
        ('Closed','Closed')
    )
    username = models.ForeignKey(User, on_delete=models.CASCADE)
    incident_place = models.TextField()
    Date_and_Time = models.DateTimeField()
    Crime_Description = models.TextField()
    complain_againts = models.TextField()
    proof = models.FileField(upload_to='proof', null=True)
    status = models.CharField(max_length=20, choices=Satus_choices)
    Reason = models.CharField(max_length=256)
    complain_Date_and_Time = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return self.username.username


class Police_Station(models.Model):
    Police_station_name = models.CharField(max_length=200)
    address = models.TextField(max_length=200)
    phone_no = models.CharField(max_length=200)

    def __str__(self):
        return self.Police_station_name


class Feedback(models.Model):
    username = models.ForeignKey(User, on_delete=models.CASCADE)
    Feedback = models.TextField()

    def __str__(self):

        return self.username.username

class Photos_Videos(models.Model):
    username = models.ForeignKey(User, on_delete=models.CASCADE)
    Description = models.CharField(max_length=100, null=True)
    Photo = models.ImageField(upload_to = "photos_videos/", max_length=500)
    Video = models.FileField(upload_to="photos_videos/", max_length=500)

    def __str__(self):
        return self.username.username

class Inspector(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    Age = models.IntegerField()
    Salary = models.DecimalField(max_digits=7,decimal_places=2)
    profile_pic = models.ImageField(upload_to='profile_pic')
    GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),
    )
    mobile_no = models.IntegerField()
    dob = models.DateField()
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    address = models.TextField()
    City = models.CharField(max_length=20)
    state = models.CharField(max_length=20)
    pincode = models.IntegerField()
    usertype = models.CharField( max_length=10,default="inspector")

    def __str__(self):
        return self.user.username

    
