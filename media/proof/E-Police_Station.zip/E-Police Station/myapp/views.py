from django.shortcuts import render
from django.http import HttpResponse , HttpResponseRedirect
from myapp import forms, models
from django.core.mail import send_mail
import random
from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.urls import reverse, reverse_lazy
from django.contrib.auth.decorators import login_required

# Create your views here.

def index(request):
    return render(request, 'index.html')

user = 0


def otp_verify(request):
    otp = request.POST.get('otp')
    uotp = request.POST.get('eotp')

    if otp == uotp:
        user.save()
        return HttpResponseRedirect(reverse('citizen_login'))
    else:
        return HttpResponse("<h1>OTP Verification Failed </h1>")

def registration(request):
    if request.method == 'POST':
        global user
        user = forms.UserModelForm(request.POST)
        otp = random.randint(111111,999999)
        if user.is_valid():
            mail = request.POST.get('email')
            pwd = request.POST.get('password')
            user = user.save(commit=False)
            user.set_password(pwd)
            send_mail(
                'OTP',
                f'Here is the otp to complete the registration {otp}.',
                settings.EMAIL_HOST_USER,
                [mail],
                fail_silently=False, )

            return render(request, 'citizen/otp.html', {'otp': otp})
    else:
        form = forms.UserModelForm()
        return render(request, 'citizen/registration.html', {'form':form})
    

def citizen_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('userpwd')
        user = authenticate(username=username, password=password)
        if user:
            if user.is_active:
                login(request, user)
                request.session['username'] = username
                request.session['usr_login'] = True

                return HttpResponseRedirect(reverse('index'))
        else:
            return HttpResponse("<h1>Username or Password is not valid</h1>")
    else:
        return render(request, 'citizen/citizen_login.html')

def citizen_logout(request):
    del request.session['usr_login']
    logout(request)
    return HttpResponseRedirect(reverse('index'))

def citizen_profile(request):

    if request.method == 'POST':
        form = forms.CitizenprofileModelForm(request.POST, request.FILES)
        if form.is_valid():
            form_obj = form.save(commit=False)
            usr = request.session['username']
            user = models.User.objects.get(username=usr)
            form_obj.user = user

            if 'profile_pic' in request.FILES:
                form_obj.profile_pic = request.FILES['profile_pic']

            form_obj.save()

            return HttpResponse('Profile saved') 
        else:
            print(form.errors)
            return HttpResponse("Invalid form")
    else:
        form = forms.CitizenprofileModelForm()
        return render(request, 'citizen/citizen_profile.html', {'form': form})

@login_required
def file_fir(request):
    if request.method == 'POST':
        form = forms.FirModelForm(request.POST, request.FILES)
        if form.is_valid():
            form_obj = form.save(commit=False)
            usr = request.session['username']
            user = models.User.objects.get(username=usr)
            form_obj.username = user

            if 'proof' in request.FILES:
                form_obj.proof = request.FILES['proof']
            form_obj.save()
            return HttpResponse('FIR Filed...') 
        else:
            print(form.errors)
            return HttpResponse("Invalid form")
    else:
        fir = forms.FirModelForm()
        return render(request, 'services/fir_form.html',{'fir':fir})

@login_required
def file_complain(request):
    if request.method == 'POST':
        form = forms.ComplainModelForm(request.POST, request.FILES)
        if form.is_valid():
            form_obj = form.save(commit=False)
            usr = request.session['username']
            user = models.User.objects.get(username=usr)
            form_obj.username = user

            if 'proof' in request.FILES:
                form_obj.proof = request.FILES['proof']
            
            form_obj.save()
            return HttpResponse('Complain Added...') 
        else:
            print(form.errors)
            return HttpResponse("Invalid form")
    else:
        form = forms.ComplainModelForm()
        return render(request, 'services/complain_form.html',{'form':form})

def police_station(request):
    if request.method == 'POST':
        form = forms.Police_StationModelForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse("Police Station Added...")
        else:
            print(form.errors)
            return HttpResponse("Invalid Form")
    else:
        form = forms.Police_StationModelForm()
        return render(request, 'police/police_station.html',{"form":form})

def search_police_station(request):
    if request.method == 'GET': 
        state = request.GET.get('state')
        city = request.GET.get('city')
        data=models.Police_Station.objects.get()
        return HttpResponse("Incomplete Functions")
    else:
        return render(request, 'police/search_police_station.html')

@login_required
def feedback(request):
    if request.method == "POST":
        form = forms.FeedbackModelForm(request.POST)
        if form.is_valid():
            form_obj = form.save(commit=False)
            usr = request.session['username']
            user = models.User.objects.get(username=usr)
            form_obj.username = user
            form.save()
            return HttpResponse("Feedback Submited...")
        else:
            print(form.errors)
            return HttpResponse("Invalid Form")
    else:
        form = forms.FeedbackModelForm()
        return render(request, 'citizen/feedback.html',{"form":form})

@login_required
def photos_videos(request):
    if request.method == "POST":
        form = forms.Photos_VideosModelForm(request.POST, request.FILES)
        if form.is_valid():
            form_obj = form.save(commit=False)
            usr = request.session['username']
            user = models.User.objects.get(username=usr)
            form_obj.username = user

            if 'Photo' in request.FILES or 'Video' in request.FILES:
                form_obj.Photo = request.FILES['Photo']
                form_obj.Video = request.FILES['Video']
            
            form_obj.save()
            return HttpResponse("<h1>Photos and Vedios Uploded...<h1>")
        else:
            print(form.errors)
            return HttpResponse("Invalid Form")
    else:
        form = forms.Photos_VideosModelForm()
        return render(request, 'citizen/photos_videos.html',{"form":form})

def inspector_index(request):
    return render(request , "inspector/inspector_index.html")

def inspector(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('userpwd')
        user = authenticate(username=username, password=password)
        if user:
            if user.is_active():
                login(request, user)
                request.session['username'] = username
                request.session['usr_login'] = True

                return HttpResponseRedirect(reverse('inspector_index'))
        else:
            return HttpResponse("<h1>Username or Password is not valid</h1>")
    else:
        return render(request, 'inspector/Inspector_login.html')
