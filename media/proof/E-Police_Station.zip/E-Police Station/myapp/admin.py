from django.contrib import admin
from myapp import models

# Register your models here.
admin.site.register(models.Citizenprofile)
admin.site.register(models.Fir)
admin.site.register(models.Complain)
admin.site.register(models.Police_Station)
admin.site.register(models.Feedback)
admin.site.register(models.Photos_Videos)
